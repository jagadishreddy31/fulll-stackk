const Complaint = require('../models/Complaint');
const Department = require('../models/Department');
const Escalation = require('../models/Escalation');

exports.createComplaint = async (req, res) => {
  try {
    const { title, description, issueType } = req.body;
    let imageUrl = '';
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    }

    // Auto-assign department based on issueType
    // For simplicity, find the first department that handles this issueType, or fallback to any
    let department = await Department.findOne({ issueTypes: issueType });
    if (!department) {
      department = await Department.findOne(); // Fallback
    }

    if (!department) {
      return res.status(400).json({ message: 'No departments available in the system.' });
    }

    // Set SLA deadline to 3 days from now
    const slaDeadline = new Date();
    slaDeadline.setDate(slaDeadline.getDate() + 3);

    const complaint = await Complaint.create({
      userId: req.user.id,
      title,
      description,
      issueType,
      imageUrl,
      departmentId: department._id,
      slaDeadline,
    });

    res.status(201).json(complaint);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getComplaints = async (req, res) => {
  try {
    let query = {};
    if (req.user.role === 'citizen') {
      query.userId = req.user.id;
    } else if (req.user.role === 'officer') {
      // Assuming user has departmentId in a complete system, for now we will send all if we dont have it.
      // If we added departmentId to user, we would do: query.departmentId = req.user.departmentId
    }

    const complaints = await Complaint.find(query).populate('departmentId', 'departmentName').populate('userId', 'name').sort({ createdAt: -1 });
    res.json(complaints);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const complaint = await Complaint.findById(id);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    complaint.status = status;
    await complaint.save();

    res.json(complaint);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getDashboardStats = async (req, res) => {
  try {
    const total = await Complaint.countDocuments();
    const resolved = await Complaint.countDocuments({ status: 'Resolved' });
    const escalated = await Complaint.countDocuments({ status: 'Escalated' });
    const inProgress = await Complaint.countDocuments({ status: { $in: ['Registered', 'In Progress'] } });
    
    res.json({ total, resolved, escalated, inProgress });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.checkSLA = async (req, res) => {
  try {
    const overdueComplaints = await Complaint.find({
      status: { $ne: 'Resolved' },
      isEscalated: false,
      slaDeadline: { $lt: new Date() }
    });

    for (let complaint of overdueComplaints) {
      complaint.status = 'Escalated';
      complaint.isEscalated = true;
      await complaint.save();

      await Escalation.create({
        complaintId: complaint._id,
        reason: 'SLA breached automatically by system script.'
      });
    }

    res.json({ message: `Escalated ${overdueComplaints.length} complaints.` });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
