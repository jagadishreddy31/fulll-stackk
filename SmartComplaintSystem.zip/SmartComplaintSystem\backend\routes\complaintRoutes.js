const express = require('express');
const router = express.Router();
const { createComplaint, getComplaints, updateStatus, getDashboardStats, checkSLA } = require('../controllers/complaintController');
const { protect, authorize } = require('../middlewares/authMiddleware');
const upload = require('../middlewares/uploadMiddleware');

router.post('/', protect, upload.single('image'), createComplaint);
router.get('/', protect, getComplaints);
router.put('/:id/status', protect, authorize('admin', 'officer'), updateStatus);
router.get('/stats', getDashboardStats);
router.post('/check-sla', protect, authorize('admin'), checkSLA);

module.exports = router;
