const mongoose = require('mongoose');

const complaintSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  issueType: { type: String, required: true }, // e.g., Road, Water, Sanitation
  imageUrl: { type: String }, // Path to uploaded image
  status: { type: String, enum: ['Registered', 'In Progress', 'Resolved', 'Escalated'], default: 'Registered' },
  departmentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true },
  slaDeadline: { type: Date, required: true },
  isEscalated: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('Complaint', complaintSchema);
