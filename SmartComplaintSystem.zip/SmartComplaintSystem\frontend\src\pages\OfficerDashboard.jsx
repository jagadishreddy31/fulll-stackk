import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { format } from 'date-fns';
import { CheckCircle, AlertTriangle, Clock } from 'lucide-react';

const OfficerDashboard = () => {
  const { user } = useContext(AuthContext);
  const [complaints, setComplaints] = useState([]);

  const fetchComplaints = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/complaints', {
        headers: { Authorization: `Bearer ${user.token}` }
      });
      setComplaints(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, []);

  const updateStatus = async (id, newStatus) => {
    try {
      await axios.put(`http://localhost:5000/api/complaints/${id}/status`, { status: newStatus }, {
        headers: { Authorization: `Bearer ${user.token}` }
      });
      fetchComplaints();
    } catch (err) {
      console.error(err);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Resolved': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'Escalated': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default: return <Clock className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Officer Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400">Manage complaints assigned to your department.</p>
      </div>

      <div className="card overflow-hidden">
        <h2 className="text-xl font-bold mb-4">Assigned Complaints</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Complaint</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Citizen</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">SLA Deadline</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Status</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Action</th>
              </tr>
            </thead>
            <tbody>
              {complaints.length === 0 ? (
                <tr><td colSpan="5" className="text-center py-8 text-gray-500">No complaints assigned.</td></tr>
              ) : (
                complaints.map(c => (
                  <tr key={c._id} className="border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <td className="py-3 px-4">
                      <div className="font-medium">{c.title}</div>
                      <div className="text-sm text-gray-500">{c.issueType}</div>
                    </td>
                    <td className="py-3 px-4">{c.userId?.name || 'Unknown'}</td>
                    <td className="py-3 px-4 text-sm text-red-500 font-medium">
                      {format(new Date(c.slaDeadline), 'MMM dd, yyyy HH:mm')}
                    </td>
                    <td className="py-3 px-4 flex items-center gap-2 mt-2">
                      {getStatusIcon(c.status)}
                      <span className="text-sm font-medium">{c.status}</span>
                    </td>
                    <td className="py-3 px-4">
                      {c.status !== 'Resolved' && c.status !== 'Escalated' && (
                        <select 
                          className="input-field py-1 px-2 text-sm max-w-[140px]" 
                          value={c.status}
                          onChange={(e) => updateStatus(c._id, e.target.value)}
                        >
                          <option value="Registered">Registered</option>
                          <option value="In Progress">In Progress</option>
                          <option value="Resolved">Resolved</option>
                        </select>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default OfficerDashboard;
