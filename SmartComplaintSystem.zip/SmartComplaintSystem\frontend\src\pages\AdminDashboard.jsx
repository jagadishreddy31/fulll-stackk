import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { BarChart3, Users, FolderOpen, AlertOctagon } from 'lucide-react';

const AdminDashboard = () => {
  const { user } = useContext(AuthContext);
  const [stats, setStats] = useState({ total: 0, resolved: 0, escalated: 0, inProgress: 0 });
  const [departments, setDepartments] = useState([]);
  const [newDeptName, setNewDeptName] = useState('');

  const fetchData = async () => {
    try {
      const statsRes = await axios.get('http://localhost:5000/api/complaints/stats');
      setStats(statsRes.data);

      const deptRes = await axios.get('http://localhost:5000/api/departments', {
        headers: { Authorization: `Bearer ${user.token}` }
      });
      setDepartments(deptRes.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCreateDept = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/departments', { departmentName: newDeptName }, {
        headers: { Authorization: `Bearer ${user.token}` }
      });
      setNewDeptName('');
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const triggerSlaCheck = async () => {
    try {
      const res = await axios.post('http://localhost:5000/api/complaints/check-sla', {}, {
        headers: { Authorization: `Bearer ${user.token}` }
      });
      alert(res.data.message);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400">System overview and management.</p>
        </div>
        <button onClick={triggerSlaCheck} className="btn-secondary text-red-600 dark:text-red-400 font-bold border border-red-200 dark:border-red-800">
          Run SLA Check Script
        </button>
      </div>

      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="card flex items-center p-6 gap-4">
          <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-full text-blue-600 dark:text-blue-400"><FolderOpen className="w-8 h-8"/></div>
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-sm font-semibold">Total Complaints</p>
            <p className="text-3xl font-bold">{stats.total}</p>
          </div>
        </div>
        <div className="card flex items-center p-6 gap-4">
          <div className="p-3 bg-green-100 dark:bg-green-900 rounded-full text-green-600 dark:text-green-400"><BarChart3 className="w-8 h-8"/></div>
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-sm font-semibold">Resolved</p>
            <p className="text-3xl font-bold">{stats.resolved}</p>
          </div>
        </div>
        <div className="card flex items-center p-6 gap-4">
          <div className="p-3 bg-yellow-100 dark:bg-yellow-900 rounded-full text-yellow-600 dark:text-yellow-400"><Users className="w-8 h-8"/></div>
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-sm font-semibold">In Progress</p>
            <p className="text-3xl font-bold">{stats.inProgress}</p>
          </div>
        </div>
        <div className="card flex items-center p-6 gap-4">
          <div className="p-3 bg-red-100 dark:bg-red-900 rounded-full text-red-600 dark:text-red-400"><AlertOctagon className="w-8 h-8"/></div>
          <div>
            <p className="text-gray-500 dark:text-gray-400 text-sm font-semibold">Escalated</p>
            <p className="text-3xl font-bold">{stats.escalated}</p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="card">
          <h2 className="text-xl font-bold mb-4">Manage Departments</h2>
          <form onSubmit={handleCreateDept} className="flex gap-2 mb-6">
            <input type="text" value={newDeptName} onChange={e => setNewDeptName(e.target.value)} required className="input-field" placeholder="New Department Name" />
            <button type="submit" className="btn-primary">Add</button>
          </form>
          
          <ul className="space-y-2">
            {departments.map(dept => (
              <li key={dept._id} className="p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg flex justify-between items-center border border-gray-100 dark:border-gray-700">
                <span className="font-medium">{dept.departmentName}</span>
                <span className="text-xs bg-gray-200 dark:bg-gray-600 px-2 py-1 rounded">ID: {dept._id.slice(-6)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
