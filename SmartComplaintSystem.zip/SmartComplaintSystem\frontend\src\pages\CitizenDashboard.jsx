import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import { format } from 'date-fns';
import { PlusCircle, Clock, CheckCircle, AlertTriangle } from 'lucide-react';

const CitizenDashboard = () => {
  const { user } = useContext(AuthContext);
  const [complaints, setComplaints] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ title: '', description: '', issueType: 'Road' });
  const [file, setFile] = useState(null);

  const fetchComplaints = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/complaints', {
        headers: { Authorization: `Bearer ${user.token}` }
      });
      setComplaints(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append('title', formData.title);
    data.append('description', formData.description);
    data.append('issueType', formData.issueType);
    if (file) data.append('image', file);

    try {
      await axios.post('http://localhost:5000/api/complaints', data, {
        headers: { 
          Authorization: `Bearer ${user.token}`,
          'Content-Type': 'multipart/form-data'
        }
      });
      setShowModal(false);
      setFormData({ title: '', description: '', issueType: 'Road' });
      setFile(null);
      fetchComplaints();
    } catch (err) {
      console.error(err);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Resolved': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'Escalated': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default: return <Clock className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Citizen Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400">Welcome, {user?.name}</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn-primary flex items-center gap-2">
          <PlusCircle className="w-5 h-5" />
          New Complaint
        </button>
      </div>

      <div className="card overflow-hidden">
        <h2 className="text-xl font-bold mb-4">Your Complaints</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-700">
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Title</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Category</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Department</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Status</th>
                <th className="py-3 px-4 font-semibold text-gray-600 dark:text-gray-300">Submitted</th>
              </tr>
            </thead>
            <tbody>
              {complaints.length === 0 ? (
                <tr><td colSpan="5" className="text-center py-8 text-gray-500">No complaints found.</td></tr>
              ) : (
                complaints.map(c => (
                  <tr key={c._id} className="border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700/50">
                    <td className="py-3 px-4 font-medium">{c.title}</td>
                    <td className="py-3 px-4">{c.issueType}</td>
                    <td className="py-3 px-4">{c.departmentId?.departmentName || 'Unassigned'}</td>
                    <td className="py-3 px-4 flex items-center gap-2">
                      {getStatusIcon(c.status)}
                      <span className="text-sm font-medium">{c.status}</span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-500">{format(new Date(c.createdAt), 'MMM dd, yyyy')}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="card w-full max-w-lg">
            <h2 className="text-2xl font-bold mb-6">Register a Complaint</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Title</label>
                <input required type="text" className="input-field" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} placeholder="E.g., Pothole on Main St" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Category</label>
                <select className="input-field" value={formData.issueType} onChange={e => setFormData({...formData, issueType: e.target.value})}>
                  <option value="Road">Road</option>
                  <option value="Water">Water</option>
                  <option value="Garbage">Garbage</option>
                  <option value="Sanitation">Sanitation</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea required className="input-field h-32" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="Provide details..."></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Evidence (Image)</label>
                <input type="file" onChange={e => setFile(e.target.files[0])} className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
              </div>
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setShowModal(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" className="btn-primary flex-1">Submit</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CitizenDashboard;
